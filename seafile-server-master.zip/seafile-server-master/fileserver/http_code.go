package main

const (
	seafHTTPResBadFileName   = 440
	seafHTTPResExists        = 441
	seafHTTPResNotExists     = 441
	seafHTTPResTooLarge      = 442
	seafHTTPResNoQuota       = 443
	seafHTTPResRepoDeleted   = 444
	seafHTTPResRepoCorrupted = 445
	seafHTTPResBlockMissing  = 446
)
