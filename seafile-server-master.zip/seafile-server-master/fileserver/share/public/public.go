// Package public manager inner public shares.
package public
