/* -*- Mode: C; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

#ifndef QUOTA_MGR_H
#define QUOTA_MGR_H

#define INFINITE_QUOTA (gint64)-2

struct _SeafQuotaManager {
    struct _SeafileSession *session;

    gboolean calc_share_usage;
};
typedef struct _SeafQuotaManager SeafQuotaManager;

SeafQuotaManager *
seaf_quota_manager_new (struct _SeafileSession *session);

int
seaf_quota_manager_init (SeafQuotaManager *mgr);

/* Set/get quota for a personal account. */
int
seaf_quota_manager_set_user_quota (SeafQuotaManager *mgr,
                                   const char *user,
                                   gint64 quota);

gint64
seaf_quota_manager_get_user_quota (SeafQuotaManager *mgr,
                                   const char *user);

gint64
seaf_quota_manager_get_user_share_usage (SeafQuotaManager *mgr,
                                         const char *user);

/*
 * Check if @repo_id still has free space for upload.
 */
int
seaf_quota_manager_check_quota (SeafQuotaManager *mgr,
                                const char *repo_id);

// ret = 0 means doesn't exceed quota,
// 1 means exceed quota,
// -1 means internal error
int
seaf_quota_manager_check_quota_with_delta (SeafQuotaManager *mgr,
                                           const char *repo_id,
                                           gint64 delta);

gint64
seaf_quota_manager_get_user_usage (SeafQuotaManager *mgr, const char *user);

GList *
seaf_repo_quota_manager_list_user_quota_usage (SeafQuotaManager *mgr);

#endif
